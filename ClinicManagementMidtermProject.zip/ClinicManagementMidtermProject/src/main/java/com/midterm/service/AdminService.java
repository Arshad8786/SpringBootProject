package com.midterm.service;

import com.midterm.entity.Admin;

public interface AdminService {
	void save(Admin admin);
}
