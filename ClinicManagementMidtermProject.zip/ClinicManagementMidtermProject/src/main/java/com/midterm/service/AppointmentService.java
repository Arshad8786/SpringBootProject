package com.midterm.service;

import java.util.List;
import java.util.Optional;

import com.midterm.entity.Appointment;

public interface AppointmentService {
	 List<Appointment> getAllAppointments();
	    Optional<Appointment> getAppointmentById(Long id);
	    Appointment saveAppointment(Appointment appointment);
	    void deleteAppointment(Long id);
	    List<Appointment> getAppointmentHistory(String username);
	    List<Appointment> getAllAppointmentByPatientId(Long patientId);
}
