package com.midterm.service;

import java.util.List;

import com.midterm.entity.Specialization;

public interface SpecializationService {
	List<Specialization> getAllSpecializations();
    Specialization getSpecializationById(Long id);
    
    void deleteSpecialization(Long id);
    Specialization getSpecializationByName(String name);
	void save(Specialization specialization);
    
}
