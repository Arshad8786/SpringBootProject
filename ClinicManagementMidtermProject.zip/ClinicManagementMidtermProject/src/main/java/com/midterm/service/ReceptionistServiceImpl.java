package com.midterm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.midterm.entity.Receptionist;
import com.midterm.repo.ReceptionistRepository;

@Service
public class ReceptionistServiceImpl implements ReceptionistService {

	@Autowired
	private ReceptionistRepository receptionistRepository;
	
	@Override
	public void save(Receptionist receptionist) {
		// TODO Auto-generated method stub
		receptionistRepository.save(receptionist);
	}

}
