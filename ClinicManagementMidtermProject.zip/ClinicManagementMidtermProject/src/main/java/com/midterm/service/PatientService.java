package com.midterm.service;

import com.midterm.entity.Patient;

public interface PatientService {
	Patient findById(Long id);
    Patient findByUsername(String username);
    void save(Patient patient);
    void update(Patient patient);
    void delete(Long id);
    Patient getPatientByUsername(String username);
}
