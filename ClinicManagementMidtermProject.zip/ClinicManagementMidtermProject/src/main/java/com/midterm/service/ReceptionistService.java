package com.midterm.service;

import com.midterm.entity.Receptionist;

public interface ReceptionistService {
	void save(Receptionist receptionist);
}
