package com.midterm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.midterm.entity.Admin;
import com.midterm.repo.AdminRepository;

@Service
public class AdminServiceImpl implements  AdminService{

	@Autowired
	private AdminRepository adminRepository;
	
	@Override
	public void save(Admin admin) {
		// TODO Auto-generated method stub
		adminRepository.save(admin);
	}

}
