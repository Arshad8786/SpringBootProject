package com.midterm.service;

import java.util.List;
import java.util.Optional;

import com.midterm.entity.Doctor;
import com.midterm.entity.Patient;

public interface DoctorService {
    List<Doctor> getAllDoctors();
    Optional<Doctor> getDoctorById(Long id);
    Doctor save(Doctor doctor);
    void deleteDoctor(Long id);
    Doctor getDoctorByUsername(String username);
	List<Doctor> findBySpecialization(String specialization);
	List<Doctor> findBySpecializationId(Long s_id);
}