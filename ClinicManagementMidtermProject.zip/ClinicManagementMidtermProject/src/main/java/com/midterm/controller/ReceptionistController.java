package com.midterm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.midterm.entity.Appointment;
import com.midterm.entity.Receptionist;
import com.midterm.entity.Specialization;
import com.midterm.service.DoctorService;
import com.midterm.service.SpecializationService;


@Controller
@RequestMapping("/receptionist")
public class ReceptionistController {

	@Autowired
	private DoctorService doctorService;
	
	@Autowired
	private SpecializationService specializationService;
	
	@GetMapping("/bookAppointmentForPatient")
    public String bookAppointment(Model model) {
		
		Appointment appointment = new Appointment();
		
		model.addAttribute("appointment",appointment);
		
        return "receptionist/bookAppointmentForPatient";
    }
	
	
	
	

}
