package com.midterm.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.midterm.entity.Appointment;
import com.midterm.entity.Doctor;
import com.midterm.entity.Patient;
import com.midterm.entity.Specialization;
import com.midterm.service.DoctorService;
import com.midterm.service.SpecializationService;

@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private SpecializationService specializationService;
	
	@Autowired
	private DoctorService doctorService;
	
	@GetMapping("/createSpecialization")
	public String createSpecialization(Model model) {
		
		Specialization specialization = new Specialization();
		
		model.addAttribute("specialization",specialization);
		
		return "admin/createSpecialization";
	}
	
	@PostMapping("/saveSpecializationForm")
	public String saveSpecializationForm(@ModelAttribute("specialization") Specialization specialization, RedirectAttributes redirectAttributes) {
	    List<Specialization> specializationList = specializationService.getAllSpecializations();
	    
	    if (specializationService.getSpecializationByName(specialization.getName()) != null) {
	        String message = "Specialization is already present. Enter a new specialization.";
	        redirectAttributes.addFlashAttribute("message", message);
	        return "redirect:/admin/createSpecialization";
	    }
	   
	    specializationService.save(specialization);
	    return "redirect:/admin/createSpecialization";
	}
	
	
	 @GetMapping("/createDoctor")
	    public String showDoctorPage(Model model) {
	        Doctor doctor = new Doctor();
	        model.addAttribute("doctor", doctor);
	        model.addAttribute("specializations", specializationService.getAllSpecializations());
	        return "admin/createDoctor";
	    }
	
	@PostMapping("/saveDoctorForm")
	public String saveDoctorForm(@ModelAttribute("doctor") Doctor doctor, @RequestParam("specialization.id") Long specializationId) {
		 System.out.println("saveDoctorForm method called"); 
		// Set the doctor role for the user
		   

		    // Retrieve the specialization entity based on the ID
		    Specialization specialization = specializationService.getSpecializationById(specializationId);

		    // Set the selected specialization for the doctor
		    doctor.setSpecialization(specialization);

		    // Save the doctor entity
		    doctorService.save(doctor);
		return "redirect:/admin/createDoctor";
	}
	
}
