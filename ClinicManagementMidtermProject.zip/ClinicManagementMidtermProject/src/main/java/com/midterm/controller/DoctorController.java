package com.midterm.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.midterm.entity.Appointment;
import com.midterm.entity.Doctor;
import com.midterm.entity.Patient;
import com.midterm.repo.DoctorRepository;
import com.midterm.repo.PatientRepository;
import com.midterm.service.AppointmentService;
import com.midterm.service.DoctorService;
import com.midterm.service.PatientService;

@Controller
@RequestMapping("/doctor")
public class DoctorController {
	
	@Autowired
	private DoctorService doctorService; 
	
	 public DoctorController(DoctorService doctorService) {
	        this.doctorService = doctorService;
	    }
	
//	@GetMapping("/doctorHome")
//    public String showDoctorHomePage(Model model) {
//	/*
//		String username = authentication.getName();   
//	 Doctor doctor = doctorService.getDoctorByUsername(authentication.getName());
//     
//        model.addAttribute("doctor", doctor);
//        model.addAttribute("name", doctor.getName());
//
//        model.addAttribute("id", doctor.getId());
//         */
//        return "doctor/doctorHome";
//    }
    
	@Autowired
	private AppointmentService appointmentService;
	
	@Autowired
	private PatientRepository patientRepository;
	@Autowired
	private DoctorRepository doctorRepository;
	
	
//	@GetMapping("/bookAppointment")
//    public String bookAppointment(Model model) {
//		
//		Appointment appointment = new Appointment();
//		
//		model.addAttribute("appointment",appointment);
//		
//        return "patient/bookAppointment";
//    }
//	
	
//	 @GetMapping("/appointmentHistory")
//	    public String showAppointmentHistory(Model model, @RequestParam("username") String username) {
//	        // Assuming you have a method to retrieve the appointment history for the given patient username
//	     System.out.println(username);  
//	     Patient patient = patientRepository.findByUsername(username);
//	        // Add other required attributes
//	        model.addAttribute("name", patient.getName());
//	        model.addAttribute("p_id", patient.getId()); 
//	        model.addAttribute("username", patient.getUsername()); 
//			
//	        model.addAttribute("patient", patient); 
//	        
//	     
//	     Long patientId = patient.getId();
//		 List<Appointment> appointments = appointmentService.getAllAppointmentByPatientId(patientId);
//	        
//	        model.addAttribute("appointments", appointments);
//	        
//	        return "patient/appointmentHistory";
//	    }
	
	 
	 @GetMapping("/doctor/{id}/appointmentHistory")
	    public String showAppointmentHistory(@PathVariable("id") Long doctorId, Model model) {
	        Optional<Doctor> doctorOptional = doctorRepository.findById(doctorId);

	        if (doctorOptional.isPresent()) {
	            Doctor doctor = doctorOptional.get();
	            model.addAttribute("name", doctor.getName());
	            model.addAttribute("appointments", doctor.getAppointments());
	            return "appointmentHistory";
	        } else {
	            // Handle doctor not found scenario
	            return "error";
	        }
	    }
	
}
