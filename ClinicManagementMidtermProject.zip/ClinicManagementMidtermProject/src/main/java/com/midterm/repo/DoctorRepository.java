package com.midterm.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.midterm.entity.Doctor;
import com.midterm.entity.Specialization;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	Doctor findByUsername(String username);
	
	List<Doctor> findBySpecialization(String specialization); 
	
	List<Doctor> findBySpecializationId(Long s_id); 
	
}
